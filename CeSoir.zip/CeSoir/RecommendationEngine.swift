import Foundation

/// Construit la sélection :
/// 1. titres « similaires » à ce que l'utilisateur aime (saisis + bien notés sur TMDB),
/// 2. découverte TMDB plateforme par plateforme (pour que chacune ait sa place),
/// 3. retrait des déjà vus et des genres à éviter,
/// 4. vérification de la disponibilité réelle en France, puis répartition équilibrée entre plateformes.
actor RecommendationEngine {
    private struct Candidate {
        var title: TMDBTitle
        var score: Double
        var reasons: [String]
        var genreLabels: [String] = []
        var foundOn: Set<Platform> = []   // plateformes dont la découverte a renvoyé ce titre
    }

    struct PlatformDiagnostic: Identifiable, Sendable {
        let platform: Platform
        let matched: [String]     // « Nom TMDB (id) » reconnus en France
        let usesFallback: Bool
        let stats: String?        // résultat de la dernière sélection pour cette plateforme
        var id: Platform { platform }
    }

    private let client = TMDBClient.shared
    private var providerCache: [MediaType: [Platform: Set<Int>]] = [:]
    private var providerNames: [MediaType: [Platform: [String]]] = [:]
    /// Pour chaque type et plateforme : titres proposés par TMDB / titres affichés.
    private var lastStats: [MediaType: [Platform: (found: Int, shown: Int)]] = [:]

    func recommend(tastes: Tastes, excluded: Set<TitleKey>, ratingSeeds: [LikedTitle]) async throws -> [Recommendation] {
        let client = self.client
        let types = tastes.format.mediaTypes
        let wanted = tastes.genres.subtracting(tastes.avoid)
        let chosen = Platform.allCases.filter { tastes.platforms.contains($0) }

        var pool: [TitleKey: Candidate] = [:]
        var successes = 0
        var lastError: Error?

        func add(_ t: TMDBTitle, score: Double, reason: String?, platform: Platform? = nil) {
            var c = pool[t.key] ?? Candidate(title: t, score: 0, reasons: [])
            c.score += score
            if let reason, !c.reasons.contains(reason) { c.reasons.append(reason) }
            if let platform { c.foundOn.insert(platform) }
            pool[t.key] = c
        }

        // 1. À partir des titres aimés
        var seedKeys = Set<TitleKey>()
        let seeds = (tastes.liked + ratingSeeds)
            .filter { types.contains($0.key.type) && seedKeys.insert($0.key).inserted }
            .prefix(8)

        let seedResults = await withTaskGroup(of: (LikedTitle, Result<[TMDBTitle], Error>).self) { group in
            for seed in seeds {
                group.addTask {
                    do { return (seed, .success(try await client.recommendations(for: seed.key))) }
                    catch { return (seed, .failure(error)) }
                }
            }
            var out: [(LikedTitle, Result<[TMDBTitle], Error>)] = []
            for await r in group { out.append(r) }
            return out
        }
        for (seed, result) in seedResults {
            switch result {
            case .success(let list):
                successes += 1
                for (i, t) in list.enumerated() { add(t, score: 3 - Double(i) * 0.05, reason: tr("Proche de \(seed.name)", "Similar to \(seed.name)")) }
            case .failure(let e):
                lastError = e
            }
        }

        // 2. Découverte : une requête par plateforme et par type, pour qu'aucune ne soit noyée
        struct DiscoverJob: Sendable { let type: MediaType; let platform: Platform; let query: [String: String] }
        var jobs: [DiscoverJob] = []
        for type in types {
            let genreIDs = Set(wanted.flatMap { $0.ids(for: type) })
            if !wanted.isEmpty && genreIDs.isEmpty { continue }   // ex. « Horreur » seul : rien côté séries
            let avoidIDs = Set(tastes.avoid.flatMap { $0.ids(for: type) })
            let providerMap = await platformIDs(for: type)

            for platform in chosen {
                guard let ids = providerMap[platform], !ids.isEmpty else { continue }
                var query: [String: String] = [
                    "watch_region": AppConfig.region,
                    "with_watch_monetization_types": "flatrate|free|ads",
                    "with_watch_providers": ids.map(String.init).joined(separator: "|"),
                    "sort_by": "popularity.desc",
                    // Arte et Apple TV+ ont des catalogues plus confidentiels : seuil de votes plus bas
                    "vote_count.gte": [.arte, .apple].contains(platform) ? "5" : "50"
                ]
                if !genreIDs.isEmpty { query["with_genres"] = genreIDs.map(String.init).joined(separator: "|") }
                if !avoidIDs.isEmpty { query["without_genres"] = avoidIDs.map(String.init).joined(separator: ",") }
                for page in 1...2 {
                    var q = query
                    q["page"] = String(page)
                    jobs.append(DiscoverJob(type: type, platform: platform, query: q))
                }
            }
        }

        let discovered = await withTaskGroup(of: (DiscoverJob, Result<[TMDBTitle], Error>).self) { group in
            for job in jobs {
                group.addTask {
                    do { return (job, .success(try await client.discover(job.type, query: job.query))) }
                    catch { return (job, .failure(error)) }
                }
            }
            var out: [(DiscoverJob, Result<[TMDBTitle], Error>)] = []
            for await r in group { out.append(r) }
            return out
        }
        var foundKeys: [Platform: Set<TitleKey>] = [:]
        for (job, result) in discovered {
            switch result {
            case .success(let list):
                successes += 1
                foundKeys[job.platform, default: []].formUnion(list.map { $0.with(job.type).key })
                for (i, t) in list.enumerated() { add(t, score: 1 - Double(i) * 0.01, reason: nil, platform: job.platform) }
            case .failure(let e):
                lastError = e
            }
        }

        if successes == 0 { throw lastError ?? TMDBError.invalidResponse }

        // 3. Filtres : déjà vus, format, genres à éviter ; bonus de genres
        var avoidByType: [MediaType: Set<Int>] = [:]
        for type in MediaType.allCases {
            avoidByType[type] = Set(tastes.avoid.flatMap { $0.ids(for: type) })
        }

        var candidates = pool.values.filter { c in
            !excluded.contains(c.title.key)
                && types.contains(c.title.mediaType)
                && avoidByType[c.title.mediaType, default: []].isDisjoint(with: c.title.genreIds)
        }
        for i in candidates.indices {
            let type = candidates[i].title.mediaType
            let matched = wanted.filter { !Set($0.ids(for: type)).isDisjoint(with: candidates[i].title.genreIds) }
            candidates[i].score += Double(matched.count) * 1.5
            candidates[i].genreLabels = matched.map(\.label).sorted()
        }
        candidates.sort { ($0.score, $0.title.popularity) > ($1.score, $1.title.popularity) }

        // Pré-sélection : les meilleurs au global + les meilleurs de chaque plateforme
        var shortlist: [Candidate] = Array(candidates.prefix(25))
        var inShortlist = Set(shortlist.map(\.title.key))
        for platform in chosen {
            for c in candidates.filter({ $0.foundOn.contains(platform) }).prefix(10) {
                if inShortlist.insert(c.title.key).inserted { shortlist.append(c) }
            }
        }

        // 4. Disponibilité réelle sur les plateformes choisies
        let availability = await withTaskGroup(of: (TitleKey, CountryProviders?).self) { group in
            for c in shortlist {
                let key = c.title.key
                group.addTask { (key, try? await client.watchProviders(for: key)) }
            }
            var out: [TitleKey: CountryProviders] = [:]
            for await (key, providers) in group { if let providers { out[key] = providers } }
            return out
        }

        var byPlatform: [Platform: [Recommendation]] = [:]
        for c in shortlist {
            guard let country = availability[c.title.key], !country.streaming.isEmpty else { continue }
            let ids = Set(country.streaming.map(\.providerId))
            let map = await platformIDs(for: c.title.mediaType)
            let available = chosen.filter { !(map[$0] ?? []).isDisjoint(with: ids) }
            guard !available.isEmpty else { continue }

            // Plateforme affichée : celle qui a proposé le titre, sinon la moins représentée pour l'instant
            let platform = available.first(where: { c.foundOn.contains($0) })
                ?? available.min(by: { byPlatform[$0, default: []].count < byPlatform[$1, default: []].count })!

            var parts: [String] = []
            if let first = c.reasons.first { parts.append(first) }
            if !c.genreLabels.isEmpty { parts.append(c.genreLabels.joined(separator: ", ").lowercased()) }
            if available.count > 1 {
                parts.append(tr("aussi sur ", "also on ") + available.filter { $0 != platform }.map(\.label).joined(separator: ", "))
            }

            byPlatform[platform, default: []].append(Recommendation(
                title: c.title,
                platform: platform,
                link: country.link.flatMap(URL.init(string:)),
                score: c.score,
                reason: parts.isEmpty ? tr("Populaire en ce moment sur \(platform.label)", "Trending now on \(platform.label)") : parts.joined(separator: " · ")
            ))
        }

        // Répartition équilibrée : on alterne les plateformes, chacune dans son ordre de score
        byPlatform = byPlatform.mapValues { $0.sorted { $0.score > $1.score } }
        var recs: [Recommendation] = []
        var round = 0
        while recs.count < 24 {
            let roundItems = chosen.compactMap { p -> Recommendation? in
                let list = byPlatform[p, default: []]
                return round < list.count ? list[round] : nil
            }
            if roundItems.isEmpty { break }
            recs += roundItems.sorted { $0.score > $1.score }
            round += 1
        }
        let final = Array(recs.prefix(24))
        if let type = types.first, types.count == 1 {
            var stats: [Platform: (found: Int, shown: Int)] = [:]
            for p in chosen {
                stats[p] = (foundKeys[p]?.count ?? 0, final.filter { $0.platform == p }.count)
            }
            lastStats[type] = stats
        }
        return final
    }

    /// Ce que TMDB reconnaît pour chaque plateforme en France (écran Compte).
    func diagnostics() async -> [PlatformDiagnostic] {
        _ = await platformIDs(for: .movie)
        _ = await platformIDs(for: .tv)
        return Platform.allCases.map { p in
            let names = Set((providerNames[.movie]?[p] ?? []) + (providerNames[.tv]?[p] ?? []))
            let parts: [String] = [(MediaType.movie, tr("Films", "Movies")), (MediaType.tv, tr("Séries", "Series"))].compactMap { pair -> String? in
                guard let s = lastStats[pair.0]?[p] else { return nil }
                return tr("\(pair.1) : \(s.found) proposés par TMDB, \(s.shown) affichés", "\(pair.1): \(s.found) found by TMDB, \(s.shown) shown")
            }
            return PlatformDiagnostic(platform: p, matched: names.sorted(), usesFallback: names.isEmpty,
                                      stats: parts.isEmpty ? nil : parts.joined(separator: " · "))
        }
    }

    /// Identifiants TMDB de chaque plateforme en France, déduits de la liste officielle (avec secours codé en dur).
    private func platformIDs(for type: MediaType) async -> [Platform: Set<Int>] {
        if let cached = providerCache[type] { return cached }
        var map: [Platform: Set<Int>] = [:]
        var names: [Platform: [String]] = [:]
        let list = try? await client.providers(type)
        if let list {
            for p in Platform.allCases {
                let found = list.filter { p.matches(providerName: $0.providerName) }
                if !found.isEmpty {
                    map[p] = Set(found.map(\.providerId))
                    names[p] = found.map { "\($0.providerName) (\($0.providerId))" }
                }
            }
        }
        for p in Platform.allCases where map[p] == nil { map[p] = p.fallbackIDs }
        if list != nil {          // ne met en cache que si TMDB a répondu
            providerCache[type] = map
            providerNames[type] = names
        }
        return map
    }
}
