import Foundation

// MARK: - Configuration

enum AppConfig {
    // ▼▼▼ LA SEULE LIGNE À REMPLIR POUR TESTER ▼▼▼
    /// Ton jeton d'accès en lecture TMDB (le long jeton qui commence par « eyJ »), entre les guillemets.
    static let tmdbToken = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5Mzk2MTk1YTJlYzc0YWVmYTRlOWE3ZjM5YmU4YzM4MSIsIm5iZiI6MTc3ODg1MjEyNy4zMDQsInN1YiI6IjZhMDcyMTFmMDQ0YmIxZTRkMTJkZGZiYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.mhgiU-S6uN8jIXWbBXLeYIknGT9i1SxdJI5b3me4wow"
    // ▲▲▲ ─────────────────────────────────── ▲▲▲

    /// Avant la publication App Store : vide `tmdbToken` (""), et l'app passera par le relais Cloudflare ci-dessous.
    static let relayBaseURL = URL(string: "https://cesoir-tmdb.TON-COMPTE.workers.dev")!
    static let relayAppKey = "REMPLACE-MOI"

    /// Mode direct (jeton dans l'app) tant qu'un jeton est renseigné.
    static var usesRelay: Bool { tmdbToken.isEmpty || tmdbToken == "COLLE-TON-JETON-ICI" }
    static var apiBaseURL: URL { usesRelay ? relayBaseURL : URL(string: "https://api.themoviedb.org")! }
    static let region = "FR"
    static var language: String { Lang.current.tmdbCode }
    /// Schéma de retour après la connexion TMDB (le relais redirige vers cesoir://tmdb-auth).
    static let authCallbackScheme = "cesoir"
}

// MARK: - Types de base

enum MediaType: String, Codable, CaseIterable, Hashable, Sendable {
    case movie, tv
    var label: String { self == .movie ? tr("Film", "Movie") : tr("Série", "Series") }
}

struct TitleKey: Hashable, Codable, Sendable {
    let type: MediaType
    let id: Int
}

enum Format: String, Codable, CaseIterable, Identifiable {
    case all, movie, tv
    var id: String { rawValue }
    var label: String {
        switch self { case .all: "Tout"; case .movie: "Films"; case .tv: "Séries" }
    }
    var mediaTypes: [MediaType] {
        switch self { case .all: [.movie, .tv]; case .movie: [.movie]; case .tv: [.tv] }
    }
}

// MARK: - Plateformes

enum Platform: String, Codable, CaseIterable, Identifiable, Sendable {
    case netflix, prime, canal, hbo, disney, apple, arte
    var id: String { rawValue }

    var label: String {
        switch self {
        case .netflix: "Netflix"
        case .prime: "Prime Video"
        case .canal: "Canal+"
        case .hbo: "HBO Max"
        case .disney: "Disney+"
        case .apple: "Apple TV+"
        case .arte: "Arte"
        }
    }

    /// Identifiants TMDB de secours si la liste des fournisseurs ne répond pas. À vérifier (surtout HBO Max).
    var fallbackIDs: Set<Int> {
        switch self {
        case .netflix: [8]
        case .prime: [119]
        case .canal: [381]
        case .hbo: [1899]
        case .disney: [337]
        case .apple: [350]
        case .arte: [234]
        }
    }

    /// Reconnaît un fournisseur TMDB par son nom (inclut les offres « avec pub », exclut les chaînes Amazon/Apple).
    func matches(providerName: String) -> Bool {
        let n = providerName.lowercased()
        if n.contains("channel") { return false }
        switch self {
        case .netflix: return n.hasPrefix("netflix")
        case .prime: return n.hasPrefix("amazon prime video")
        case .canal: return n.hasPrefix("canal+") || n.hasPrefix("canal plus")
        case .hbo: return n == "max" || n.contains("hbo")
        case .disney: return n.hasPrefix("disney plus") || n.hasPrefix("disney+")
        case .apple: return n.hasPrefix("apple tv") && !n.contains("store")
        case .arte: return n == "arte"
        }
    }
}

// MARK: - Genres (identifiants TMDB films / séries)

enum AppGenre: String, Codable, CaseIterable, Identifiable, Sendable {
    case action, animation, comedie, policier, documentaire, drame
    case fantastique, scienceFiction, histoire, horreur, thriller, romance, guerre

    var id: String { rawValue }

    var label: String {
        switch self {
        case .action: tr("Action", "Action")
        case .animation: tr("Animation", "Animation")
        case .comedie: tr("Comédie", "Comedy")
        case .policier: tr("Policier", "Crime")
        case .documentaire: tr("Documentaire", "Documentary")
        case .drame: tr("Drame", "Drama")
        case .fantastique: tr("Fantastique", "Fantasy")
        case .scienceFiction: tr("Science-fiction", "Sci-fi")
        case .histoire: tr("Historique", "History")
        case .horreur: tr("Horreur", "Horror")
        case .thriller: tr("Thriller", "Thriller")
        case .romance: tr("Romance", "Romance")
        case .guerre: tr("Guerre & politique", "War & politics")
        }
    }

    /// En séries, TMDB regroupe science-fiction et fantastique (10765) : exclure l'un exclut l'autre.
    func ids(for type: MediaType) -> [Int] {
        switch (self, type) {
        case (.action, .movie): [28, 12]
        case (.action, .tv): [10759]
        case (.animation, _): [16]
        case (.comedie, _): [35]
        case (.policier, _): [80]
        case (.documentaire, _): [99]
        case (.drame, _): [18]
        case (.fantastique, .movie): [14]
        case (.fantastique, .tv): [10765]
        case (.scienceFiction, .movie): [878]
        case (.scienceFiction, .tv): [10765]
        case (.histoire, .movie): [36]
        case (.histoire, .tv): []
        case (.horreur, .movie): [27]
        case (.horreur, .tv): []
        case (.thriller, .movie): [53, 9648]
        case (.thriller, .tv): [9648]
        case (.romance, .movie): [10749]
        case (.romance, .tv): []
        case (.guerre, .movie): [10752]
        case (.guerre, .tv): [10768]
        }
    }
}

// MARK: - Goûts de l'utilisateur

struct LikedTitle: Codable, Hashable, Sendable {
    let key: TitleKey
    let name: String
}

struct Tastes: Codable {
    var liked: [LikedTitle] = []
    var genres: Set<AppGenre> = []
    var avoid: Set<AppGenre> = []
    var platforms: Set<Platform> = Set(Platform.allCases)
    var format: Format = .all
}

// MARK: - Modèles TMDB

struct Paged<T: Decodable>: Decodable {
    let page: Int
    let results: [T]
    let totalPages: Int
    let totalResults: Int
}

/// Un film ou une série, quel que soit l'endpoint (discover, recommandations, recherche, notes).
struct TMDBTitle: Decodable, Hashable, Identifiable, Sendable {
    let id: Int
    var mediaType: MediaType
    let isTitle: Bool          // false pour une personne dans search/multi
    let name: String
    let date: String?
    let overview: String
    let posterPath: String?
    let genreIds: [Int]
    let voteAverage: Double
    let voteCount: Int
    let popularity: Double
    let rating: Double?        // présent dans les listes de notes du compte

    var key: TitleKey { TitleKey(type: mediaType, id: id) }
    var year: String? { date.flatMap { $0.count >= 4 ? String($0.prefix(4)) : nil } }
    var posterURL: URL? { posterPath.flatMap { URL(string: "https://image.tmdb.org/t/p/w342\($0)") } }

    func with(_ type: MediaType) -> TMDBTitle { var c = self; c.mediaType = type; return c }

    enum CodingKeys: String, CodingKey {
        case id, mediaType, title, name, releaseDate, firstAirDate, overview
        case posterPath, genreIds, voteAverage, voteCount, popularity, rating
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(Int.self, forKey: .id)
        let movieTitle = try c.decodeIfPresent(String.self, forKey: .title)
        let tvName = try c.decodeIfPresent(String.self, forKey: .name)
        let rawType = try c.decodeIfPresent(String.self, forKey: .mediaType)
        isTitle = rawType != "person"
        if let rawType, let t = MediaType(rawValue: rawType) {
            mediaType = t
        } else {
            mediaType = movieTitle != nil ? .movie : .tv
        }
        name = movieTitle ?? tvName ?? "Sans titre"
        let release = try c.decodeIfPresent(String.self, forKey: .releaseDate)
        let firstAir = try c.decodeIfPresent(String.self, forKey: .firstAirDate)
        date = [release, firstAir].compactMap { $0 }.first { !$0.isEmpty }
        overview = try c.decodeIfPresent(String.self, forKey: .overview) ?? ""
        posterPath = try c.decodeIfPresent(String.self, forKey: .posterPath)
        genreIds = try c.decodeIfPresent([Int].self, forKey: .genreIds) ?? []
        voteAverage = try c.decodeIfPresent(Double.self, forKey: .voteAverage) ?? 0
        voteCount = try c.decodeIfPresent(Int.self, forKey: .voteCount) ?? 0
        popularity = try c.decodeIfPresent(Double.self, forKey: .popularity) ?? 0
        rating = try c.decodeIfPresent(Double.self, forKey: .rating)
    }
}

struct Provider: Decodable, Hashable, Sendable {
    let providerId: Int
    let providerName: String
    let logoPath: String?
}

struct ProviderList: Decodable { let results: [Provider] }

struct CountryProviders: Decodable, Sendable {
    let link: String?
    let flatrate: [Provider]?
    let free: [Provider]?
    let ads: [Provider]?

    /// Tout ce qui se regarde sans achat ni location : abonnement, gratuit (Arte), gratuit avec pub.
    var streaming: [Provider] { (flatrate ?? []) + (free ?? []) + (ads ?? []) }
}

struct WatchProvidersResponse: Decodable {
    let id: Int
    let results: [String: CountryProviders]
}

struct TMDBAccount: Codable, Hashable {
    let id: Int
    let username: String
}

struct TMDBStatus: Decodable {
    let success: Bool?
    let statusMessage: String?
}

struct RequestTokenResponse: Decodable { let requestToken: String }
struct SessionResponse: Decodable { let sessionId: String }
struct RequestTokenBody: Encodable { let requestToken: String }
struct SessionBody: Encodable { let sessionId: String }
struct EmptyBody: Encodable {}

// MARK: - Résultat affiché

struct Recommendation: Identifiable, Hashable {
    let title: TMDBTitle
    let platform: Platform
    let link: URL?
    let score: Double
    let reason: String
    var id: TitleKey { title.key }
}
