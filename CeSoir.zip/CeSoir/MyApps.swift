import Observation
import SwiftUI

// MARK: - Catalogue Michel Garlandat

/// Catégories du panneau « Mes Apps ».
enum AppCategory: String, CaseIterable, Identifiable {
    case geographie, histoireFrance, histoireMonde, culture, paris, monuments, jeux, kids, utilitaires
    var id: String { rawValue }

    var label: String {
        switch self {
        case .geographie: tr("Géographie", "Geography")
        case .histoireFrance: tr("Histoire de France", "French History")
        case .histoireMonde: tr("Histoire du Monde", "World History")
        case .culture: tr("Culture", "Culture")
        case .paris: tr("Paris", "Paris")
        case .monuments: tr("Monuments", "Landmarks")
        case .jeux: tr("Jeux", "Games")
        case .kids: tr("Kids", "Kids")
        case .utilitaires: tr("Utilitaires", "Utilities")
        }
    }
}

struct CatalogApp: Identifiable, Hashable {
    let id: Int          // identifiant App Store (sans « id »)
    let name: String     // nom de secours si l'App Store ne répond pas
}

/// Les noms affichés viennent de l'App Store (dans la langue choisie) ; ceux-ci servent de secours.
struct AppSection: Identifiable {
    let category: AppCategory
    let apps: [CatalogApp]
    var id: AppCategory { category }
    init(_ category: AppCategory, _ apps: [CatalogApp]) { self.category = category; self.apps = apps }
}

let myAppsCatalog: [AppSection] = [
    AppSection(.geographie, [
        CatalogApp(id: 6770453028, name: "France Geo Quiz"),
        CatalogApp(id: 6770458593, name: "Europe Geo Quiz"),
        CatalogApp(id: 6770826067, name: "Europe Hors UE Geo Quiz"),
        CatalogApp(id: 6770566450, name: "Amérique du Nord Geo Quiz"),
        CatalogApp(id: 6770580053, name: "Amérique du Sud Geo Quiz"),
        CatalogApp(id: 6770857576, name: "Asie Geo Quiz"),
        CatalogApp(id: 6770836826, name: "Afrique Geo Quiz"),
        CatalogApp(id: 6770848617, name: "Moyen-Orient Geo Quiz"),
        CatalogApp(id: 6762346365, name: "Pays UE"),
        CatalogApp(id: 6761421276, name: "Capitales Europe"),
        CatalogApp(id: 6762370541, name: "États-Unis"),
        CatalogApp(id: 6762598304, name: "Mers & Océans"),
        CatalogApp(id: 6762594201, name: "Détroits"),
        CatalogApp(id: 6767810270, name: "Îles du Monde"),
        CatalogApp(id: 6779307504, name: "Monde en Blocs"),
    ]),
    AppSection(.histoireFrance, [
        CatalogApp(id: 6761322546, name: "Rois de France"),
        CatalogApp(id: 6761324444, name: "Présidents Français"),
        CatalogApp(id: 6761374601, name: "Maréchaux de Napoléon"),
        CatalogApp(id: 6762542395, name: "Conquêtes Sociales"),
        CatalogApp(id: 6768320574, name: "Légion d'Honneur"),
        CatalogApp(id: 6761334922, name: "Académie française"),
        CatalogApp(id: 6761769529, name: "Institut de France"),
    ]),
    AppSection(.histoireMonde, [
        CatalogApp(id: 6762208827, name: "Dynasties Royales"),
        CatalogApp(id: 6762098486, name: "Familles Royales"),
        CatalogApp(id: 6762522136, name: "Dynasties Chinoises"),
        CatalogApp(id: 6762452564, name: "Dynasties Russes"),
        CatalogApp(id: 6762256169, name: "Présidents Américains"),
        CatalogApp(id: 6762263227, name: "Leaders Européens"),
        CatalogApp(id: 6763569148, name: "Nobels de la Paix"),
        CatalogApp(id: 6767492967, name: "Institutions Mondiales"),
        CatalogApp(id: 6768003416, name: "Explorateurs du Monde"),
        CatalogApp(id: 6766260978, name: "Histoire Informatique"),
        CatalogApp(id: 6766261703, name: "Histoire Micro-Informatique"),
    ]),
    AppSection(.culture, [
        CatalogApp(id: 6768068634, name: "Peintres Célèbres"),
        CatalogApp(id: 6770302783, name: "Architectes Célèbres"),
        CatalogApp(id: 6780762142, name: "Réalisateurs Célèbres"),
        CatalogApp(id: 6761656628, name: "Compositeurs"),
        CatalogApp(id: 6767135193, name: "Auteurs de BD"),
        CatalogApp(id: 6769653710, name: "Légendes Pop"),
        CatalogApp(id: 6762006105, name: "Iconic Covers"),
        CatalogApp(id: 6770102339, name: "Athlètes Célèbres"),
        CatalogApp(id: 6761993002, name: "Comédie-Française"),
        CatalogApp(id: 6763069304, name: "Avions de Légende"),
        CatalogApp(id: 6763071567, name: "Voitures de Légende"),
        CatalogApp(id: 6762632868, name: "Trains Mythiques"),
        CatalogApp(id: 6763076110, name: "Paquebots"),
        CatalogApp(id: 6764087562, name: "Aéroports Mythiques"),
        CatalogApp(id: 6767273597, name: "Machines Légendaires"),
        CatalogApp(id: 6761685637, name: "Arbres de France"),
        CatalogApp(id: 6773255479, name: "Rosiers du Monde"),
        CatalogApp(id: 6779975160, name: "Recettes de France"),
    ]),
    AppSection(.paris, [
        CatalogApp(id: 6771671461, name: "Panorama Paris"),
        CatalogApp(id: 6780015911, name: "Rues Mythiques de Paris"),
        CatalogApp(id: 6760890465, name: "Musées Paris"),
        CatalogApp(id: 6760929391, name: "Théâtres Paris"),
        CatalogApp(id: 6761293938, name: "Scènes Paris"),
        CatalogApp(id: 6760751055, name: "Cimetières Paris"),
        CatalogApp(id: 6761363063, name: "Sénat"),
        CatalogApp(id: 6761361079, name: "Assemblée nationale"),
        CatalogApp(id: 6763507194, name: "Hôtels Rooftop Paris"),
        CatalogApp(id: 6821262827, name: "Gares du Grand Paris"),
        CatalogApp(id: 6764868620, name: "Forts de Paris"),
    ]),
    AppSection(.monuments, [
        CatalogApp(id: 6779549736, name: "Paris Monuments"),
        CatalogApp(id: 6761335268, name: "Panthéon"),
        CatalogApp(id: 6761709149, name: "Basilique Saint-Denis"),
        CatalogApp(id: 6762823383, name: "Châteaux de la Loire"),
        CatalogApp(id: 6762618424, name: "Ponts du Monde"),
        CatalogApp(id: 6763857843, name: "Gratte-Ciels du Monde"),
    ]),
    AppSection(.jeux, [
        CatalogApp(id: 6814862033, name: "500 Questions"),
        CatalogApp(id: 6768574161, name: "Tuiles Numériques"),
        CatalogApp(id: 6813926243, name: "Lettres Rami"),
        CatalogApp(id: 6812248979, name: "Mots Révélés"),
        CatalogApp(id: 6762552826, name: "Lexigo"),
        CatalogApp(id: 6772450908, name: "Mahjong Dynasties"),
        CatalogApp(id: 6769310796, name: "Solitaire"),
        CatalogApp(id: 6762076518, name: "Dames"),
        CatalogApp(id: 6762091681, name: "Bataille Navale"),
        CatalogApp(id: 6762558969, name: "ColorCodeMind"),
        CatalogApp(id: 6762077646, name: "Flip Board"),
        CatalogApp(id: 6821636268, name: "Lucioles"),
    ]),
    AppSection(.kids, [
        CatalogApp(id: 6773000126, name: "Coloriage"),
        CatalogApp(id: 6815129888, name: "Formes et Couleurs Kids"),
        CatalogApp(id: 6773621753, name: "Mémo Animaux"),
        CatalogApp(id: 6773656650, name: "Petit Bilingue"),
        CatalogApp(id: 6773037110, name: "Dinosaures"),
        CatalogApp(id: 6772937635, name: "Animaux"),
        CatalogApp(id: 6772548541, name: "Lettres"),
        CatalogApp(id: 6772546976, name: "Chiffres"),
        CatalogApp(id: 6772468506, name: "Mahjong Kids"),
        CatalogApp(id: 6812044055, name: "Piano for Kids"),
        CatalogApp(id: 6812048568, name: "Bubbles for Kids"),
        CatalogApp(id: 6813807264, name: "Kiki Match"),
    ]),
    AppSection(.utilitaires, [
        CatalogApp(id: 6760617965, name: "Mes Restaurants"),
        CatalogApp(id: 6760126279, name: "Cave Manager"),
        CatalogApp(id: 6759219383, name: "FreshFood Manager"),
        CatalogApp(id: 6761271324, name: "MediSafe"),
        CatalogApp(id: 1538282211, name: "MGHealth"),
        CatalogApp(id: 1475789193, name: "Devises Convertisseur"),
        CatalogApp(id: 1483084001, name: "Belote Calc"),
        CatalogApp(id: 1481989301, name: "Tarots Calc"),
        CatalogApp(id: 1475884625, name: "Toi ou Moi"),
    ]),
]

// MARK: - Icônes et noms depuis l'App Store

private struct LookupResponse: Decodable {
    struct Item: Decodable {
        let trackId: Int
        let trackName: String?
        let artworkUrl100: String?
        let artworkUrl512: String?
    }
    let results: [Item]
}

/// Un seul appel groupé à l'API iTunes (jusqu'à 180 identifiants par appel) :
/// un appel par app dépasse la limite de débit d'Apple et les icônes ne se chargent pas.
@Observable
@MainActor
final class AppIconStore {
    private(set) var icons: [Int: URL] = [:]
    private(set) var names: [Int: String] = [:]
    private var loadedLang: Lang?

    func load(lang: Lang) async {
        guard loadedLang != lang else { return }
        let ids = myAppsCatalog.flatMap { $0.apps.map(\.id) }
        var newNames: [Int: String] = [:]
        var newIcons = icons
        for chunk in stride(from: 0, to: ids.count, by: 180).map({ Array(ids[$0..<min($0 + 180, ids.count)]) }) {
            var comps = URLComponents(string: "https://itunes.apple.com/lookup")!
            comps.queryItems = [
                URLQueryItem(name: "id", value: chunk.map(String.init).joined(separator: ",")),
                URLQueryItem(name: "country", value: "fr"),
                URLQueryItem(name: "lang", value: lang.itunesCode),
                URLQueryItem(name: "entity", value: "software"),
            ]
            guard let url = comps.url,
                  let (data, _) = try? await URLSession.shared.data(from: url),
                  let response = try? JSONDecoder().decode(LookupResponse.self, from: data) else { continue }
            for item in response.results {
                if let name = item.trackName { newNames[item.trackId] = name }
                if let art = item.artworkUrl512 ?? item.artworkUrl100, let u = URL(string: art) {
                    newIcons[item.trackId] = u
                }
            }
        }
        if !newNames.isEmpty {
            names = newNames
            icons = newIcons
            loadedLang = lang
        }
    }
}

// MARK: - Écran « Mes Apps »

struct MyAppsView: View {
    @Environment(AppModel.self) private var model
    @State private var store = AppIconStore()

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 10, alignment: .top), count: 4)

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 22) {
                ForEach(myAppsCatalog) { section in
                    VStack(alignment: .leading, spacing: 12) {
                        Text(section.category.label)
                            .font(.headline)
                            .padding(.horizontal, 4)
                        LazyVGrid(columns: columns, spacing: 14) {
                            ForEach(section.apps) { app in
                                AppTile(
                                    app: app,
                                    name: store.names[app.id] ?? app.name,
                                    icon: store.icons[app.id]
                                )
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .navigationTitle(tr("Mes Apps", "My Apps"))
        .task(id: model.lang) { await store.load(lang: model.lang) }
    }
}

private struct AppTile: View {
    let app: CatalogApp
    let name: String
    let icon: URL?

    var body: some View {
        Link(destination: URL(string: "https://apps.apple.com/app/id\(app.id)")!) {
            VStack(spacing: 5) {
                AsyncImage(url: icon) { image in
                    image.resizable().scaledToFill()
                } placeholder: {
                    Color.secondary.opacity(0.15)
                }
                .frame(width: 56, height: 56)
                .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 13, style: .continuous)
                        .stroke(Color.primary.opacity(0.08), lineWidth: 0.5)
                )
                Text(name)
                    .font(.system(size: 10))
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity)
            }
        }
        .accessibilityLabel(name)
    }
}
