import Foundation
import Observation

@Observable
@MainActor
final class AppModel {
    enum Tab: Hashable { case tastes, movies, series, account, apps }

    /// Langue de l'interface et des données TMDB. Changer de langue relance les sélections.
    var lang: Lang = Lang.current {
        didSet {
            guard lang != oldValue else { return }
            UserDefaults.standard.set(lang.rawValue, forKey: Lang.storageKey)
            results = [:]
            errorMessages = [:]
            Task { await refreshAll() }
        }
    }

    func toggleLanguage() { lang = lang.other }

    var selectedTab: Tab = .tastes
    var tastes: Tastes { didSet { persist(tastes, key: Keys.tastes) } }

    /// Une sélection séparée pour les films et pour les séries.
    var results: [MediaType: [Recommendation]] = [:]
    var loading: Set<MediaType> = []
    var errorMessages: [MediaType: String] = [:]

    let seen = SeenStore()

    private(set) var account: TMDBAccount?
    var isSyncing = false
    var syncMessage: String?

    /// Titres notés 8/10 et plus sur TMDB : servent de goûts en plus des titres saisis.
    private var ratingSeeds: [LikedTitle] { didSet { persist(ratingSeeds, key: Keys.seeds) } }

    private let engine = RecommendationEngine()
    private let authenticator = TMDBAuthenticator()

    private enum Keys {
        static let tastes = "tastes", seeds = "ratingSeeds", account = "tmdbAccount", session = "tmdbSession"
    }

    init() {
        let savedTastes = Self.restore(Tastes.self, key: Keys.tastes)
        tastes = savedTastes ?? Tastes()
        // Premier lancement : on commence par les goûts. Ensuite : directement sur les films.
        selectedTab = savedTastes == nil ? .tastes : .movies
        ratingSeeds = Self.restore([LikedTitle].self, key: Keys.seeds) ?? []
        // Reprise : les anciens « titres aimés » deviennent des déjà vus avec un cœur
        if !tastes.liked.isEmpty {
            for t in tastes.liked { seen.markLiked(key: t.key, name: t.name) }
            tastes.liked = []
            persist(tastes, key: Keys.tastes)
        }
        if Keychain.get(Keys.session) != nil {
            account = Self.restore(TMDBAccount.self, key: Keys.account)
        }
    }

    // MARK: Sélection

    /// Relance les deux sélections (films et séries) en parallèle.
    func refreshAll() async {
        async let movies: Void = refresh(.movie)
        async let shows: Void = refresh(.tv)
        _ = await (movies, shows)
    }

    func refresh(_ type: MediaType) async {
        guard !loading.contains(type) else { return }
        loading.insert(type)
        errorMessages[type] = nil
        defer { loading.remove(type) }

        var query = tastes
        query.format = type == .movie ? .movie : .tv
        // Les coups de cœur (déjà vus avec un cœur) servent de point de départ
        query.liked = seen.likedEntries.map { LikedTitle(key: $0.key, name: $0.name) }
        let excluded = seen.keys
        do {
            let list = try await engine.recommend(tastes: query, excluded: excluded, ratingSeeds: ratingSeeds)
            results[type] = list
            if list.isEmpty {
                errorMessages[type] = tr("Rien trouvé avec ces critères. Ajoute des plateformes ou élargis les genres.", "Nothing found with these criteria. Add platforms or broaden the genres.")
            }
        } catch {
            errorMessages[type] = error.localizedDescription
        }
    }

    /// Déjà vu + coup de cœur, depuis une carte de sélection.
    func markLoved(_ rec: Recommendation) {
        seen.mark(rec.title, liked: true)
        results[rec.title.mediaType]?.removeAll { $0.id == rec.id }
    }

    func toggleLike(_ entry: SeenStore.Entry) { seen.toggleLike(entry.key) }

    func markSeen(_ title: TMDBTitle) {
        seen.mark(title)
        results[title.mediaType]?.removeAll { $0.id == title.key }
    }

    func markSeen(_ rec: Recommendation) { markSeen(rec.title) }

    /// Retire un titre des déjà vus : il pourra de nouveau être proposé à la prochaine sélection.
    func restore(_ entry: SeenStore.Entry) { seen.remove(entry.key) }

    func search(_ query: String) async -> [TMDBTitle] {
        (try? await TMDBClient.shared.searchMulti(query)) ?? []
    }

    // MARK: Plateformes reconnues

    var diagnostics: [RecommendationEngine.PlatformDiagnostic] = []

    func loadDiagnostics() async {
        diagnostics = await engine.diagnostics()
    }

    // MARK: Compte TMDB

    func connect() async {
        do {
            let (sessionId, acc) = try await authenticator.signIn()
            Keychain.set(sessionId, for: Keys.session)
            account = acc
            persist(acc, key: Keys.account)
            await sync()
        } catch AuthError.cancelled {
            // L'utilisateur a fermé la fenêtre : rien à signaler.
        } catch {
            syncMessage = error.localizedDescription
        }
    }

    /// Importe les notes du compte : toutes deviennent « déjà vues », les 8/10+ deviennent des goûts.
    func sync() async {
        guard let account, let sessionId = Keychain.get(Keys.session) else { return }
        isSyncing = true
        defer { isSyncing = false }
        do {
            async let movies = TMDBClient.shared.rated(.movie, accountId: account.id, sessionId: sessionId)
            async let shows = TMDBClient.shared.rated(.tv, accountId: account.id, sessionId: sessionId)
            let all = try await movies + shows

            seen.replaceTMDB(with: all)
            ratingSeeds = all
                .filter { ($0.rating ?? 0) >= 8 }
                .sorted { ($0.rating ?? 0) > ($1.rating ?? 0) }
                .prefix(10)
                .map { LikedTitle(key: $0.key, name: $0.name) }
            syncMessage = tr("\(all.count) titres notés importés comme déjà vus.", "\(all.count) rated titles imported as already watched.")
        } catch TMDBError.http(401, _) {
            await disconnect()
            syncMessage = tr("Session TMDB expirée. Reconnecte-toi.", "TMDB session expired. Please sign in again.")
        } catch {
            syncMessage = error.localizedDescription
        }
    }

    func disconnect() async {
        if let sessionId = Keychain.get(Keys.session) {
            try? await TMDBClient.shared.deleteSession(sessionId)
        }
        Keychain.delete(Keys.session)
        UserDefaults.standard.removeObject(forKey: Keys.account)
        account = nil
        ratingSeeds = []
        seen.removeAll(source: .tmdb)
    }

    // MARK: Persistance légère

    private func persist<T: Encodable>(_ value: T, key: String) {
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: key) }
    }

    private static func restore<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }
}
