import AuthenticationServices
import Foundation
import Security
import UIKit

// MARK: - Trousseau (session TMDB)

enum Keychain {
    private static let service = "CeSoir.TMDB"

    static func set(_ value: String, for account: String) {
        delete(account)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: Data(value.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    static func get(_ account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var out: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete(_ account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}

// MARK: - Connexion au compte TMDB

enum AuthError: LocalizedError {
    case cancelled, denied, couldNotStart

    var errorDescription: String? {
        switch self {
        case .cancelled: tr("Connexion annulée.", "Sign-in cancelled.")
        case .denied: tr("Tu n'as pas autorisé l'accès sur TMDB.", "You did not allow access on TMDB.")
        case .couldNotStart: tr("Impossible d'ouvrir la page de connexion TMDB.", "Could not open the TMDB sign-in page.")
        }
    }
}

/// Flux TMDB v3 : jeton → validation sur themoviedb.org → session.
/// TMDB renvoie vers le relais (/auth/callback), qui redirige vers cesoir://tmdb-auth.
@MainActor
final class TMDBAuthenticator: NSObject, ASWebAuthenticationPresentationContextProviding {
    private var current: ASWebAuthenticationSession?

    func signIn() async throws -> (sessionId: String, account: TMDBAccount) {
        let client = TMDBClient.shared
        let token = try await client.newRequestToken()

        // En mode relais, TMDB revient par le relais ; en mode direct, on tente le retour direct vers l'app.
        let redirect = AppConfig.usesRelay
            ? AppConfig.relayBaseURL.appending(path: "auth/callback").absoluteString
            : "\(AppConfig.authCallbackScheme)://tmdb-auth"
        var comps = URLComponents(string: "https://www.themoviedb.org/authenticate/\(token)")!
        comps.queryItems = [URLQueryItem(name: "redirect_to", value: redirect)]
        guard let authURL = comps.url else { throw AuthError.couldNotStart }

        let callback: URL?
        do {
            callback = try await waitForCallback(authURL)
        } catch AuthError.cancelled {
            // Si TMDB n'a pas renvoyé vers l'app, l'utilisateur a pu valider puis fermer la fenêtre :
            // on tente quand même d'ouvrir la session avec le jeton.
            callback = nil
        }

        if let callback {
            let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
            if items.first(where: { $0.name == "denied" })?.value == "true" { throw AuthError.denied }
        }

        let sessionId: String
        do {
            sessionId = try await client.createSession(requestToken: token)
        } catch {
            throw callback == nil ? AuthError.cancelled : error
        }
        let account = try await client.account(sessionId: sessionId)
        return (sessionId, account)
    }

    private func waitForCallback(_ authURL: URL) async throws -> URL {
        let result: URL = try await withCheckedThrowingContinuation { cont in
            let session = ASWebAuthenticationSession(
                url: authURL, callbackURLScheme: AppConfig.authCallbackScheme
            ) { url, error in
                if let url {
                    cont.resume(returning: url)
                } else if let e = error as? ASWebAuthenticationSessionError, e.code == .canceledLogin {
                    cont.resume(throwing: AuthError.cancelled)
                } else {
                    cont.resume(throwing: error ?? AuthError.couldNotStart)
                }
            }
            session.presentationContextProvider = self
            session.prefersEphemeralWebBrowserSession = false
            current = session
            if !session.start() { cont.resume(throwing: AuthError.couldNotStart) }
        }
        current = nil
        return result
    }

    nonisolated func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        MainActor.assumeIsolated {
            UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .flatMap(\.windows)
                .first { $0.isKeyWindow } ?? ASPresentationAnchor()
        }
    }
}
