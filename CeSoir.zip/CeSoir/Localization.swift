import Foundation

/// Langue de l'app, choisie avec le drapeau 🇫🇷/🇬🇧 dans l'en-tête.
/// Par défaut : français si l'iPhone est en français, anglais sinon.
enum Lang: String, Codable, Sendable {
    case fr, en

    static let storageKey = "appLanguage"

    static var current: Lang {
        if let raw = UserDefaults.standard.string(forKey: storageKey), let lang = Lang(rawValue: raw) {
            return lang
        }
        return Locale.preferredLanguages.first?.hasPrefix("fr") == true ? .fr : .en
    }

    var flag: String { self == .fr ? "🇫🇷" : "🇬🇧" }
    var other: Lang { self == .fr ? .en : .fr }

    /// Langue demandée à TMDB pour les titres et résumés.
    var tmdbCode: String { self == .fr ? "fr-FR" : "en-US" }
    /// Langue demandée à l'App Store pour les noms d'apps.
    var itunesCode: String { self == .fr ? "fr_fr" : "en_us" }
}

/// Texte dans la langue en cours : tr("Films", "Movies").
func tr(_ fr: String, _ en: String) -> String {
    Lang.current == .fr ? fr : en
}
