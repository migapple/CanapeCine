import Foundation

enum TMDBError: LocalizedError {
    case http(Int, String)
    case invalidResponse
    case notConfigured

    var errorDescription: String? {
        switch self {
        case .http(401, _): tr("Accès TMDB refusé (session expirée ou clé invalide).", "TMDB access denied (expired session or invalid key).")
        case .http(429, _): tr("TMDB reçoit trop de demandes. Réessaie dans un instant.", "TMDB is receiving too many requests. Try again shortly.")
        case .http(let code, let msg): msg.isEmpty ? tr("Erreur TMDB (\(code)).", "TMDB error (\(code)).") : tr("Erreur TMDB (\(code)) : \(msg)", "TMDB error (\(code)): \(msg)")
        case .invalidResponse: tr("Réponse inattendue du serveur.", "Unexpected server response.")
        case .notConfigured: tr("Jeton TMDB manquant : colle-le dans Models.swift (tmdbToken), puis relance l'app.", "Missing TMDB token: paste it in Models.swift (tmdbToken), then relaunch the app.")
        }
    }
}

/// Limite le nombre de requêtes simultanées (TMDB refuse les rafales).
actor RequestLimiter {
    private var available: Int
    private var waiters: [CheckedContinuation<Void, Never>] = []

    init(_ limit: Int) { available = limit }

    func acquire() async {
        if available > 0 { available -= 1; return }
        await withCheckedContinuation { waiters.append($0) }
    }

    func release() {
        if waiters.isEmpty { available += 1 } else { waiters.removeFirst().resume() }
    }
}

/// Accès à l'API TMDB v3 : en direct avec ton jeton (tests), ou via le relais (publication).
actor TMDBClient {
    static let shared = TMDBClient()

    private let base = AppConfig.apiBaseURL
    private let session = URLSession.shared
    private let limiter = RequestLimiter(8)
    private let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.keyDecodingStrategy = .convertFromSnakeCase
        return d
    }()
    private let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.keyEncodingStrategy = .convertToSnakeCase
        return e
    }()

    func get<T: Decodable>(_ path: String, _ query: [String: String] = [:]) async throws -> T {
        try await request("GET", path, query, body: Optional<EmptyBody>.none)
    }

    func request<T: Decodable, B: Encodable>(
        _ method: String, _ path: String, _ query: [String: String] = [:], body: B?
    ) async throws -> T {
        if AppConfig.usesRelay && AppConfig.relayAppKey == "REMPLACE-MOI" { throw TMDBError.notConfigured }
        guard var comps = URLComponents(url: base.appending(path: "3/" + path), resolvingAgainstBaseURL: false) else {
            throw TMDBError.invalidResponse
        }
        var items = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        if query["language"] == nil { items.append(URLQueryItem(name: "language", value: AppConfig.language)) }
        comps.queryItems = items

        guard let url = comps.url else { throw TMDBError.invalidResponse }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if AppConfig.usesRelay {
            req.setValue(AppConfig.relayAppKey, forHTTPHeaderField: "X-App-Key")
        } else {
            req.setValue("Bearer \(AppConfig.tmdbToken)", forHTTPHeaderField: "Authorization")
        }
        if let body {
            req.httpBody = try encoder.encode(body)
            req.setValue("application/json;charset=utf-8", forHTTPHeaderField: "Content-Type")
        }

        // 8 requêtes à la fois au maximum ; en cas de refus pour excès (429), on attend puis on réessaie.
        var attempt = 0
        var data = Data()
        var lastHTTP: HTTPURLResponse?
        while true {
            await limiter.acquire()
            let result: (Data, URLResponse)
            do {
                result = try await session.data(for: req)
            } catch {
                await limiter.release()
                throw error
            }
            await limiter.release()
            guard let h = result.1 as? HTTPURLResponse else { throw TMDBError.invalidResponse }
            data = result.0
            lastHTTP = h
            if h.statusCode == 429 && attempt < 3 {
                attempt += 1
                let wait = Double(h.value(forHTTPHeaderField: "Retry-After") ?? "") ?? Double(attempt)
                try await Task.sleep(for: .seconds(min(wait, 5)))
                continue
            }
            break
        }
        guard let http = lastHTTP else { throw TMDBError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let msg = (try? decoder.decode(TMDBStatus.self, from: data))?.statusMessage ?? ""
            throw TMDBError.http(http.statusCode, msg)
        }
        return try decoder.decode(T.self, from: data)
    }
}

// MARK: - Catalogue

extension TMDBClient {
    /// Découverte filtrée (plateformes, genres, région FR).
    func discover(_ type: MediaType, query: [String: String]) async throws -> [TMDBTitle] {
        let page: Paged<TMDBTitle> = try await get("discover/\(type.rawValue)", query)
        return page.results.map { $0.with(type) }
    }

    /// Titres « similaires » à un titre aimé.
    func recommendations(for key: TitleKey) async throws -> [TMDBTitle] {
        let page: Paged<TMDBTitle> = try await get("\(key.type.rawValue)/\(key.id)/recommendations", ["page": "1"])
        return page.results.map { $0.with(key.type) }
    }

    /// Où regarder ce titre en France (données JustWatch).
    func watchProviders(for key: TitleKey) async throws -> CountryProviders? {
        let r: WatchProvidersResponse = try await get("\(key.type.rawValue)/\(key.id)/watch/providers")
        return r.results[AppConfig.region]
    }

    /// Liste des plateformes disponibles en France pour ce type de contenu.
    func providers(_ type: MediaType) async throws -> [Provider] {
        let r: ProviderList = try await get("watch/providers/\(type.rawValue)", ["watch_region": AppConfig.region])
        return r.results
    }

    func searchMulti(_ query: String) async throws -> [TMDBTitle] {
        let page: Paged<TMDBTitle> = try await get("search/multi", ["query": query, "include_adult": "false"])
        return page.results.filter(\.isTitle)
    }
}

// MARK: - Compte utilisateur

extension TMDBClient {
    func newRequestToken() async throws -> String {
        let r: RequestTokenResponse = try await get("authentication/token/new")
        return r.requestToken
    }

    func createSession(requestToken: String) async throws -> String {
        let r: SessionResponse = try await request("POST", "authentication/session/new",
                                                   body: RequestTokenBody(requestToken: requestToken))
        return r.sessionId
    }

    func account(sessionId: String) async throws -> TMDBAccount {
        try await get("account", ["session_id": sessionId])
    }

    func deleteSession(_ sessionId: String) async throws {
        let _: TMDBStatus = try await request("DELETE", "authentication/session",
                                              body: SessionBody(sessionId: sessionId))
    }

    /// Tous les titres notés par l'utilisateur (paginé, 50 pages max par sécurité).
    func rated(_ type: MediaType, accountId: Int, sessionId: String) async throws -> [TMDBTitle] {
        let segment = type == .movie ? "movies" : "tv"
        var all: [TMDBTitle] = []
        var page = 1
        var totalPages = 1
        repeat {
            let p: Paged<TMDBTitle> = try await get("account/\(accountId)/rated/\(segment)", [
                "session_id": sessionId, "page": String(page), "sort_by": "created_at.desc"
            ])
            all += p.results.map { $0.with(type) }
            totalPages = p.totalPages
            page += 1
        } while page <= min(totalPages, 50)
        return all
    }
}
