import SwiftUI

/// Écran « Déjà vus » : affiches, filtre Films / Séries, recherche, et remise dans la sélection.
struct SeenListView: View {
    enum Filter: Hashable { case all, movies, series, loved }

    @Environment(AppModel.self) private var model
    @State private var filter: Filter = .all
    @State private var query = ""
    @State private var showSearch = false

    private var entries: [SeenStore.Entry] {
        let q = query.trimmingCharacters(in: .whitespaces).folding(options: [.diacriticInsensitive, .caseInsensitive], locale: nil)
        return model.seen.sorted.filter { entry -> Bool in
            let typeOK: Bool = switch filter {
                case .all: true
                case .movies: entry.key.type == .movie
                case .series: entry.key.type == .tv
                case .loved: entry.isLiked
            }
            return typeOK
                && (q.isEmpty || entry.name.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: nil).contains(q))
        }
    }

    var body: some View {
        List {
            Section {
                Picker(tr("Type", "Type"), selection: $filter) {
                    Text(tr("Tout", "All")).tag(Filter.all)
                    Text(tr("Films", "Movies")).tag(Filter.movies)
                    Text(tr("Séries", "Series")).tag(Filter.series)
                    Image(systemName: "heart.fill").tag(Filter.loved)
                }
                .pickerStyle(.segmented)
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets())
            }

            Section {
                ForEach(entries) { entry in
                    SeenRow(entry: entry) { model.toggleLike(entry) }
                        .swipeActions {
                            Button(tr("Remettre", "Restore"), systemImage: "arrow.uturn.backward") {
                                model.restore(entry)
                            }
                            .tint(.green)
                        }
                        .contextMenu {
                            Button(entry.isLiked ? tr("Retirer le cœur", "Remove heart") : tr("Mettre un cœur", "Add heart"),
                                   systemImage: entry.isLiked ? "heart.slash" : "heart") { model.toggleLike(entry) }
                            Button(tr("Remettre dans la sélection", "Restore to picks"),
                                   systemImage: "arrow.uturn.backward") { model.restore(entry) }
                        }
                }
            } footer: {
                if !entries.isEmpty {
                    Text(tr("Touche le cœur pour les titres que tu as adorés : ils guident tes sélections. Glisse vers la gauche pour remettre un titre dans la sélection.",
                            "Tap the heart for titles you loved: they guide your picks. Swipe left to restore a title to your picks."))
                }
            }
        }
        .overlay {
            if entries.isEmpty {
                if !query.isEmpty {
                    ContentUnavailableView.search(text: query)
                } else {
                    ContentUnavailableView(
                        tr("Aucun titre déjà vu", "No watched titles"),
                        systemImage: "eye.slash",
                        description: Text(tr("Glisse une carte vers la gauche dans Films ou Séries, ou ajoute un titre avec le bouton +.",
                                             "Swipe a card left in Movies or Series, or add a title with the + button."))
                    )
                }
            }
        }
        .searchable(text: $query, prompt: tr("Rechercher", "Search"))
        .animation(.default, value: model.seen.entries.count)
        .navigationTitle(tr("Déjà vus", "Watched"))
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(tr("Ajouter", "Add"), systemImage: "plus") { showSearch = true }
            }
        }
        .sheet(isPresented: $showSearch) {
            TitleSearchView(title: tr("Déjà vu", "Watched")) { picked in model.markSeen(picked) }
        }
    }
}

private struct SeenRow: View {
    let entry: SeenStore.Entry
    let onToggleLike: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            AsyncImage(url: entry.posterURL) { image in
                image.resizable().scaledToFill()
            } placeholder: {
                ZStack {
                    Color.secondary.opacity(0.15)
                    Image(systemName: entry.key.type == .movie ? "film" : "tv")
                        .foregroundStyle(.secondary)
                }
            }
            .frame(width: 44, height: 66)
            .clipShape(RoundedRectangle(cornerRadius: 6))

            VStack(alignment: .leading, spacing: 3) {
                Text(entry.name).font(.headline).lineLimit(2)
                HStack(spacing: 6) {
                    Text([entry.key.type.label, entry.year].compactMap { $0 }.joined(separator: " · "))
                    if entry.source == .tmdb {
                        Text("TMDB")
                            .font(.caption2.bold())
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1)
                            .background(Color.secondary.opacity(0.15), in: Capsule())
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Spacer(minLength: 8)

            Button(action: onToggleLike) {
                Image(systemName: entry.isLiked ? "heart.fill" : "heart")
                    .font(.title2)
                    .foregroundStyle(entry.isLiked ? Color.pink : Color.secondary)
                    .contentTransition(.symbolEffect(.replace))
            }
            .buttonStyle(.borderless)
            .sensoryFeedback(.selection, trigger: entry.isLiked)
            .accessibilityLabel(entry.isLiked ? tr("Retirer le cœur", "Remove heart") : tr("Mettre un cœur", "Add heart"))
        }
        .padding(.vertical, 2)
    }
}
