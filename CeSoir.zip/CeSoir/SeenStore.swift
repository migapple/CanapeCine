import Foundation
import Observation

/// Titres déjà vus : ajoutés à la main ou importés des notes TMDB. Stockés dans Application Support.
@Observable
@MainActor
final class SeenStore {
    enum Source: String, Codable { case manual, tmdb }

    struct Entry: Codable, Hashable, Identifiable {
        let key: TitleKey
        let name: String
        let source: Source
        let date: Date
        // Ajoutés plus tard : absents des anciennes sauvegardes, d'où les optionnels
        var posterPath: String?
        var year: String?
        var liked: Bool?

        var id: TitleKey { key }
        /// Coup de cœur : guide les sélections (titres similaires).
        var isLiked: Bool { liked == true }
        var posterURL: URL? { posterPath.flatMap { URL(string: "https://image.tmdb.org/t/p/w185\($0)") } }
    }

    private struct SaveFile: Codable {
        var entries: [Entry]
        /// Titres notés sur TMDB que l'utilisateur a remis dans la sélection : on ne les réimporte pas.
        var restoredTMDB: [TitleKey]
    }

    private(set) var entries: [TitleKey: Entry] = [:]
    private var restoredTMDB: Set<TitleKey> = []

    var keys: Set<TitleKey> { Set(entries.keys) }
    var sorted: [Entry] { entries.values.sorted { $0.date > $1.date } }
    var likedEntries: [Entry] { sorted.filter(\.isLiked) }

    init() { load() }

    func contains(_ key: TitleKey) -> Bool { entries[key] != nil }

    func mark(_ title: TMDBTitle, liked: Bool = false, source: Source = .manual) {
        if var existing = entries[title.key] {
            if liked && !existing.isLiked { existing.liked = true; entries[title.key] = existing; save() }
            return
        }
        entries[title.key] = Entry(key: title.key, name: title.name, source: source, date: .now,
                                   posterPath: title.posterPath, year: title.year, liked: liked ? true : nil)
        restoredTMDB.remove(title.key)
        save()
    }

    /// Ajout sans fiche complète (reprise des anciens « titres aimés »).
    func markLiked(key: TitleKey, name: String) {
        if var existing = entries[key] {
            existing.liked = true
            entries[key] = existing
        } else {
            entries[key] = Entry(key: key, name: name, source: .manual, date: .now, liked: true)
        }
        save()
    }

    func toggleLike(_ key: TitleKey) {
        guard var entry = entries[key] else { return }
        entry.liked = entry.isLiked ? nil : true
        entries[key] = entry
        save()
    }

    /// Remet le titre dans les sélections.
    func remove(_ key: TitleKey) {
        if entries[key]?.source == .tmdb { restoredTMDB.insert(key) }
        entries[key] = nil
        save()
    }

    /// Remplace les entrées TMDB par la liste à jour, sans toucher aux ajouts manuels
    /// ni aux titres que l'utilisateur a volontairement remis dans la sélection.
    func replaceTMDB(with titles: [TMDBTitle]) {
        // On garde les ajouts manuels et les titres TMDB marqués d'un cœur
        entries = entries.filter { $0.value.source == .manual || $0.value.isLiked }
        for t in titles where entries[t.key] == nil && !restoredTMDB.contains(t.key) {
            entries[t.key] = Entry(key: t.key, name: t.name, source: .tmdb, date: .now,
                                   posterPath: t.posterPath, year: t.year)
        }
        save()
    }

    func removeAll(source: Source) {
        entries = entries.filter { $0.value.source != source }
        if source == .tmdb { restoredTMDB = [] }
        save()
    }

    // MARK: Persistance

    private var fileURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appending(path: "seen.json")
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        let list: [Entry]
        if let file = try? JSONDecoder().decode(SaveFile.self, from: data) {
            list = file.entries
            restoredTMDB = Set(file.restoredTMDB)
        } else if let old = try? JSONDecoder().decode([Entry].self, from: data) {
            list = old   // ancien format (simple liste)
        } else {
            return
        }
        entries = Dictionary(list.map { ($0.key, $0) }, uniquingKeysWith: { a, _ in a })
    }

    private func save() {
        let file = SaveFile(entries: Array(entries.values), restoredTMDB: Array(restoredTMDB))
        guard let data = try? JSONEncoder().encode(file) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}
