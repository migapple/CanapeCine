import SwiftUI

extension Platform {
    var color: Color {
        switch self {
        case .netflix: .red
        case .prime: Color(red: 0.0, green: 0.62, blue: 0.9)
        case .canal: .gray
        case .hbo: .purple
        case .disney: .blue
        case .apple: .primary
        case .arte: .orange
        }
    }
}

// MARK: - Racine

struct RootView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        @Bindable var model = model
        TabView(selection: $model.selectedTab) {
            NavigationStack { TastesView().languageToggle() }
                .tabItem { Label(tr("Mes goûts", "My tastes"), systemImage: "slider.horizontal.3") }
                .tag(AppModel.Tab.tastes)
            NavigationStack { ResultsView(type: .movie).languageToggle() }
                .tabItem { Label(tr("Films", "Movies"), systemImage: "film") }
                .tag(AppModel.Tab.movies)
            NavigationStack { ResultsView(type: .tv).languageToggle() }
                .tabItem { Label(tr("Séries", "Series"), systemImage: "tv") }
                .tag(AppModel.Tab.series)
            NavigationStack { AccountView().languageToggle() }
                .tabItem { Label(tr("Compte", "Account"), systemImage: "person.crop.circle") }
                .tag(AppModel.Tab.account)
            NavigationStack { MyAppsView().languageToggle() }
                .tabItem { Label(tr("Mes Apps", "My Apps"), systemImage: "square.grid.2x2") }
                .tag(AppModel.Tab.apps)
        }
        // Reconstruit toute l'interface quand la langue change
        .id(model.lang)
    }
}

/// Drapeau 🇫🇷/🇬🇧 dans l'en-tête : affiche la langue active, un appui bascule vers l'autre.
private struct LanguageToggle: ViewModifier {
    @Environment(AppModel.self) private var model

    func body(content: Content) -> some View {
        content.toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    model.toggleLanguage()
                } label: {
                    Text(model.lang.flag).font(.title2)
                }
                .accessibilityLabel(tr("Passer en anglais", "Switch to French"))
            }
        }
    }
}

extension View {
    func languageToggle() -> some View { modifier(LanguageToggle()) }
}

// MARK: - Goûts

struct TastesView: View {
    @Environment(AppModel.self) private var model
    @State private var searchTarget: SearchTarget?

    enum SearchTarget: String, Identifiable {
        case seen
        var id: String { rawValue }
    }

    var body: some View {
        @Bindable var model = model
        Form {
            Section {
                NavigationLink {
                    SeenListView()
                } label: {
                    LabeledContent {
                        Text("\(model.seen.entries.count)").monospacedDigit()
                    } label: {
                        Label(tr("Déjà vus", "Watched"), systemImage: "eye.slash")
                    }
                }
                Button(tr("Ajouter un titre déjà vu", "Add a watched title"), systemImage: "plus") { searchTarget = .seen }
            } footer: {
                Text(model.account != nil
                     ? tr("Mets un cœur sur les titres que tu as adorés : ils guident tes sélections, comme tes notes 8/10 et plus sur TMDB.",
                          "Add a heart to the titles you loved: they guide your picks, like your TMDB ratings of 8/10 or more.")
                     : tr("Mets un cœur sur les titres que tu as adorés : ils guident tes sélections.",
                          "Add a heart to the titles you loved: they guide your picks."))
            }

            Section(tr("Genres", "Genres")) {
                ChipGrid(items: AppGenre.allCases, selection: $model.tastes.genres, label: \.label)
            }

            Section {
                ChipGrid(items: AppGenre.allCases, selection: $model.tastes.avoid, label: \.label, tint: .red)
            } header: {
                Text(tr("À éviter", "Avoid"))
            } footer: {
                Text(tr("En séries, TMDB regroupe science-fiction et fantastique : exclure l'un exclut l'autre.", "For series, TMDB groups sci-fi and fantasy together: excluding one excludes the other."))
            }

            Section(tr("Mes plateformes", "My platforms")) {
                ForEach(Platform.allCases) { p in
                    Toggle(isOn: Binding(
                        get: { model.tastes.platforms.contains(p) },
                        set: { on in
                            if on { model.tastes.platforms.insert(p) } else { model.tastes.platforms.remove(p) }
                        }
                    )) {
                        Label { Text(p.label) } icon: { Circle().fill(p.color).frame(width: 10, height: 10) }
                    }
                }
            }


            Section {
                Button {
                    if model.selectedTab == .tastes { model.selectedTab = .movies }
                    Task { await model.refreshAll() }
                } label: {
                    Text(tr("Voir ma sélection", "Show my picks")).bold().frame(maxWidth: .infinity)
                }
                .disabled(model.tastes.platforms.isEmpty)
            }
        }
        .navigationTitle(tr("Mes goûts", "My tastes"))
        .sheet(item: $searchTarget) { target in
            TitleSearchView(title: tr("Déjà vu", "Watched")) { picked in
                model.markSeen(picked)
            }
        }
    }
}

struct ChipGrid<Item: Hashable>: View {
    let items: [Item]
    @Binding var selection: Set<Item>
    let label: (Item) -> String
    var tint: Color = .accentColor

    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 104), spacing: 8)], spacing: 8) {
            ForEach(items, id: \.self) { item in
                let on = selection.contains(item)
                Button {
                    if on { selection.remove(item) } else { selection.insert(item) }
                } label: {
                    Text(label(item))
                        .font(.subheadline)
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 7)
                        .background(on ? tint : Color.secondary.opacity(0.12), in: Capsule())
                        .foregroundStyle(on ? Color.white : Color.primary)
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(on ? .isSelected : [])
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Sélection

struct ResultsView: View {
    let type: MediaType
    @Environment(AppModel.self) private var model
    /// true : liste groupée par plateforme ; false : liste par pertinence. Mémorisé entre les lancements.
    @AppStorage("groupByPlatform") private var groupByPlatform = true

    private var items: [Recommendation] { model.results[type] ?? [] }
    private var isLoading: Bool { model.loading.contains(type) }
    private var title: String { type == .movie ? tr("Films", "Movies") : tr("Séries", "Series") }

    /// Plateformes dans l'ordre habituel, chacune avec ses titres du plus au moins pertinent.
    private struct PlatformGroup: Identifiable {
        let platform: Platform
        let items: [Recommendation]
        var id: Platform { platform }
    }

    private var groups: [PlatformGroup] {
        Platform.allCases.compactMap { p in
            let list = items.filter { $0.platform == p }.sorted { $0.score > $1.score }
            return list.isEmpty ? nil : PlatformGroup(platform: p, items: list)
        }
    }

    var body: some View {
        List {
            if groupByPlatform {
                ForEach(groups) { group in
                    Section {
                        ForEach(group.items) { row($0) }
                    } header: {
                        HStack(spacing: 8) {
                            Circle().fill(group.platform.color).frame(width: 10, height: 10)
                            Text(group.platform.label).font(.headline).foregroundStyle(.primary)
                            Spacer()
                            Text("\(group.items.count)").font(.subheadline.monospacedDigit()).foregroundStyle(.secondary)
                        }
                        .textCase(nil)
                    }
                }
            } else {
                ForEach(items) { row($0) }
            }
        }
        .listStyle(.plain)
        .overlay {
            if items.isEmpty {
                if isLoading {
                    ProgressView(tr("Recherche sur tes plateformes…", "Searching your platforms…"))
                } else {
                    ContentUnavailableView(
                        tr("Pas encore de sélection", "No picks yet"),
                        systemImage: type == .movie ? "film" : "tv",
                        description: Text(model.errorMessages[type] ?? tr("Renseigne tes goûts, puis tire vers le bas pour lancer la sélection.", "Set your tastes, then pull down to get your picks."))
                    )
                }
            }
        }
        .refreshable { await model.refresh(type) }
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                if isLoading && !items.isEmpty { ProgressView() }
            }
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Picker(tr("Trier", "Sort"), selection: $groupByPlatform) {
                        Label(tr("Par plateforme", "By platform"), systemImage: "square.stack.3d.up").tag(true)
                        Label(tr("Par pertinence", "By relevance"), systemImage: "star").tag(false)
                    }
                } label: {
                    Label(tr("Trier", "Sort"), systemImage: "arrow.up.arrow.down")
                }
            }
        }
        .navigationTitle(title)
        .task { if model.results[type] == nil { await model.refresh(type) } }
    }

    private func row(_ rec: Recommendation) -> some View {
        RecommendationRow(rec: rec)
            .swipeActions {
                Button(tr("Déjà vu", "Watched"), systemImage: "eye.slash") { model.markSeen(rec) }
                    .tint(.indigo)
            }
            .swipeActions(edge: .leading) {
                Button(tr("Adoré", "Loved"), systemImage: "heart.fill") { model.markLoved(rec) }
                    .tint(.pink)
            }
            .contextMenu {
                Button(tr("Déjà vu", "Watched"), systemImage: "eye.slash") { model.markSeen(rec) }
                Button(tr("Déjà vu et adoré", "Watched and loved"), systemImage: "heart") { model.markLoved(rec) }
            }
    }
}

struct RecommendationRow: View {
    let rec: Recommendation

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            AsyncImage(url: rec.title.posterURL) { image in
                image.resizable().scaledToFill()
            } placeholder: {
                Color.secondary.opacity(0.15)
            }
            .frame(width: 70, height: 105)
            .clipShape(RoundedRectangle(cornerRadius: 8))

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Label(rec.platform.label, systemImage: "play.tv")
                        .font(.caption.bold())
                        .foregroundStyle(rec.platform.color)
                    Spacer()
                    if rec.title.voteAverage > 0 {
                        Text(rec.title.voteAverage, format: .number.precision(.fractionLength(1)))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                    }
                }
                Text(rec.title.name).font(.headline)
                Text([rec.title.mediaType.label, rec.title.year].compactMap { $0 }.joined(separator: " · "))
                    .font(.caption).foregroundStyle(.secondary)
                Text(rec.reason).font(.caption).foregroundStyle(.secondary)
                if !rec.title.overview.isEmpty {
                    Text(rec.title.overview).font(.footnote).lineLimit(3)
                }
                if let link = rec.link {
                    Link(tr("Où regarder", "Where to watch"), destination: link).font(.caption)
                }
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Compte

struct AccountView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        Form {
            Section {
                if let account = model.account {
                    LabeledContent(tr("Connecté", "Signed in"), value: account.username)
                    Button {
                        Task { await model.sync() }
                    } label: {
                        if model.isSyncing { ProgressView() } else { Text(tr("Synchroniser mes notes", "Sync my ratings")) }
                    }
                    .disabled(model.isSyncing)
                    Button(tr("Se déconnecter", "Sign out"), role: .destructive) {
                        Task { await model.disconnect() }
                    }
                } else {
                    Button(tr("Se connecter à TMDB", "Sign in to TMDB")) { Task { await model.connect() } }
                }
                if let message = model.syncMessage {
                    Text(message).font(.footnote).foregroundStyle(.secondary)
                }
            } header: {
                Text(tr("Compte TMDB", "TMDB account"))
            } footer: {
                Text(tr("Les titres notés sur TMDB sont considérés comme déjà vus. Ceux notés 8/10 ou plus servent aussi à affiner tes goûts.", "Titles rated on TMDB count as watched. Those rated 8/10 or more also refine your tastes."))
            }

            Section {
                NavigationLink {
                    SeenListView()
                } label: {
                    LabeledContent {
                        Text("\(model.seen.entries.count)").monospacedDigit()
                    } label: {
                        Label(tr("Déjà vus", "Watched"), systemImage: "eye.slash")
                    }
                }
            }

            #if DEBUG
            // Visible seulement quand l'app est lancée depuis Xcode (absent de la version App Store)
            Section {
                ForEach(model.diagnostics) { d in
                    VStack(alignment: .leading, spacing: 2) {
                        Text(d.platform.label).font(.subheadline.bold())
                        Text(d.usesFallback
                             ? tr("Non trouvée dans la liste TMDB France : identifiant de secours ", "Not found in the TMDB France list: fallback ID ") + d.platform.fallbackIDs.map(String.init).joined(separator: ", ")
                             : d.matched.joined(separator: ", "))
                            .font(.caption)
                            .foregroundStyle(d.usesFallback ? Color.orange : Color.secondary)
                        if let stats = d.stats {
                            Text(stats).font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
            } header: {
                Text(tr("Plateformes reconnues en France", "Platforms recognized in France"))
            }
            .task(id: model.loading.count) { await model.loadDiagnostics() }
            #endif

            Section {
                LabeledContent(tr("Canapé Ciné", "Couch Cinema"),
                               value: "v" + (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"))
                TMDBAttribution()
                Text(tr("Disponibilités : JustWatch", "Availability: JustWatch"))
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } header: {
                Text(tr("À propos", "About"))
            } footer: {
                // Mention exigée par TMDB, texte officiel laissé en anglais, dans la section « À propos ».
                Text("This product uses the TMDB API but is not endorsed or certified by TMDB.")
                    .font(.caption2)
            }
        }
        .navigationTitle(tr("Compte", "Account"))
    }
}

// MARK: - Recherche de titre

struct TitleSearchView: View {
    let title: String
    let onPick: (TMDBTitle) -> Void

    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var results: [TMDBTitle] = []

    var body: some View {
        NavigationStack {
            List(results, id: \.key) { t in
                Button {
                    onPick(t)
                    dismiss()
                } label: {
                    HStack(spacing: 12) {
                        AsyncImage(url: t.posterURL) { $0.resizable().scaledToFill() } placeholder: {
                            Color.secondary.opacity(0.15)
                        }
                        .frame(width: 40, height: 60)
                        .clipShape(RoundedRectangle(cornerRadius: 5))
                        VStack(alignment: .leading) {
                            Text(t.name).foregroundStyle(.primary)
                            Text([t.mediaType.label, t.year].compactMap { $0 }.joined(separator: " · "))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .overlay {
                if results.isEmpty && query.count >= 2 { ContentUnavailableView.search(text: query) }
            }
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: tr("Film ou série", "Movie or series"))
            .task(id: query) {
                guard query.count >= 2 else { results = []; return }
                try? await Task.sleep(for: .milliseconds(350))
                guard !Task.isCancelled else { return }
                results = await model.search(query)
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button(tr("Fermer", "Close")) { dismiss() } }
            }
        }
    }
}

// MARK: - Attribution TMDB (obligatoire)

/// Logo officiel TMDB, à ajouter dans Assets.xcassets sous le nom « TMDBLogo ».
/// Tant que l'image n'est pas ajoutée, un texte la remplace pour ne rien casser.
struct TMDBAttribution: View {
    var body: some View {
        Link(destination: URL(string: "https://www.themoviedb.org")!) {
            HStack {
                if UIImage(named: "TMDBLogo") != nil {
                    Image("TMDBLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 22)
                } else {
                    Text("TMDB").font(.footnote.bold())
                }
                Spacer()
                Text(tr("Films et séries fournis par TMDB", "Movies and series provided by TMDB"))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .accessibilityLabel("The Movie Database (TMDB)")
    }
}
